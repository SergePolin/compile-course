package com.compiler;

public class SimpleType extends Type {
    public SimpleType(String name) {
        super(name);
    }

    public String getName() {
        return name;
    }
}
