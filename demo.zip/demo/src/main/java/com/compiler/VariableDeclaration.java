package com.compiler;

public interface VariableDeclaration {
    // Interface for variable declarations

    public String getName();
    public Type getType();
}
